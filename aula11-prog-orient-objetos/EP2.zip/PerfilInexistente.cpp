#include "PerfilInexistente.h"
using namespace std;



PerfilInexistente::PerfilInexistente() : logic_error("Perfil Inexistente")
{

}

PerfilInexistente::~PerfilInexistente()
{

}
