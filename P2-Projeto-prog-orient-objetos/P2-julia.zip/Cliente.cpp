#include "Cliente.h"

// CLASSE JA IMPLEMENTADA. NAO ALTERE

Cliente::Cliente(string nome) : nome(nome) {
}

Cliente::~Cliente() {
}

string Cliente::getNome() {
    return nome;
}

